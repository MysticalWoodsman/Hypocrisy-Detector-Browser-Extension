document.addEventListener('DOMContentLoaded', function () {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    var url = tabs[0].url;
    var urlDisplay = document.getElementById('url-display');
    urlDisplay.innerHTML = '<span style="font-size: larger; font-weight: bold;">Analyzing... ' + url + '</span>'; // Display "Analyzing... [URL]"

    // Send data to parse.php immediately upon extension activation
    fetch('http://mysticalwoodsman.x10.mx/hypo/extract.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: 'input_text=' + encodeURIComponent(url),
    })
      .then((response) => response.text())
      .then((data) => {
        if (data.trim() === 'Plan 2') {
          urlDisplay.innerHTML = '<span style="font-size: 14pt;">Analyzing YouTube is only available in the Premium Version. <a href="http://mysticalwoodsman.x10.mx/hypo/index.html" target="_blank">Click HERE</a> to upgrade.</span>';
        } else {
          // Replace \n with actual line breaks
          var formattedData = data.replace(/\n/g, '<br>');
          // Update the content with the formatted data and set background color to yellow
          urlDisplay.innerHTML = formattedData;
          urlDisplay.style.backgroundColor = 'yellow'; // Set background color to yellow
        }
        
        // Add buttons after fetching data
        addButtonContainer(urlDisplay);
      });
  });
});

function addButtonContainer(urlDisplay) {
  var shareButton = document.createElement('button');
  shareButton.textContent = 'Share';
  shareButton.addEventListener('click', function () {
    openNewTab('http://mysticalwoodsman.x10.mx/hypo/discussions/share.php');
  });

  var joinDiscussionButton = document.createElement('button');
  joinDiscussionButton.textContent = 'Join Discussion';
  joinDiscussionButton.addEventListener('click', function () {
    openNewTab('http://mysticalwoodsman.x10.mx/hypo/discussions/index.html');
  });

  var buttonContainer = document.createElement('div');
  buttonContainer.style.display = 'flex';
  buttonContainer.style.justifyContent = 'space-between';
  buttonContainer.appendChild(shareButton);
  buttonContainer.appendChild(joinDiscussionButton);
  urlDisplay.appendChild(buttonContainer);
}

function openNewTab(url) {
  window.open(url, '_blank');
}
